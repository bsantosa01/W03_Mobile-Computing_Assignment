//
//  ContentView.swift
//  W03 - Mobile Computing - Brant Marvel Santosa - 0706022310005
//

import SwiftUI

struct ContentView: View {
    @State private var musicList = ["Rock", "Jazz", "Pop", "Classical"]
    @State private var movieList = ["Inception", "Interstellar", "Avengers", "Parasite"]
    @State private var sportList = ["Football", "Basketball", "Badminton", "Tennis"]
    @State private var bookList = ["1984", "Harry Potter", "The Hobbit", "Atomic Habits"]
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                // Profile Header
                HStack {
                    Image(systemName: "person.circle.fill")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 120, height: 120)
                        .foregroundColor(.blue)
                    
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Brant Marvel Santosa")
                            .font(.title2).bold()
                        Text("Information System for Business - Data Science")
                            .font(.headline)
                            .foregroundColor(.secondary)
                        Text("20 years old")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }
                }
                
                Divider()
                    .padding(.vertical, 20)
                
                // Grid of Navigation Cards
                VStack(spacing: 16) {
                    HStack(spacing: 16) {
                        NavigationLink(destination: ListView(title: "🎵 Music", items: $musicList)) {
                            CardView(title: "🎵 Music", color: .purple)
                        }
                        
                        NavigationLink(destination: ListView(title: "🎬 Movies", items: $movieList)) {
                            CardView(title: "🎬 Movies", color: .red)
                        }
                    }
                    
                    HStack(spacing: 16) {
                        NavigationLink(destination: ListView(title: "⚽ Sports", items: $sportList)) {
                            CardView(title: "⚽ Sports", color: .green)
                        }
                        
                        NavigationLink(destination: ListView(title: "📚 Books", items: $bookList)) {
                            CardView(title: "📚 Books", color: .orange)
                        }
                    }
                }
                
                Spacer()
            }
            .padding()
            .toolbar {
                ToolbarItemGroup(placement: .bottomBar) {
                    HStack(spacing: 20) {
                        NavigationLink(destination: ListView(title: "🎵 Music", items: $musicList)) {
                            Image(systemName: "music.note.list")
                                .foregroundColor(.purple)
                                .frame(width: 50, height: 50)
                                .background(Circle().fill(Color.white))
                                .shadow(radius: 3)
                        }
                        
                        NavigationLink(destination: ListView(title: "🎬 Movies", items: $movieList)) {
                            Image(systemName: "film")
                                .foregroundColor(.red)
                                .frame(width: 50, height: 50)
                                .background(Circle().fill(Color.white))
                                .shadow(radius: 3)
                        }
                        
                        NavigationLink(destination: ListView(title: "⚽ Sports", items: $sportList)) {
                            Image(systemName: "sportscourt")
                                .foregroundColor(.green)
                                .frame(width: 50, height: 50)
                                .background(Circle().fill(Color.white))
                                .shadow(radius: 3)
                        }
                        
                        NavigationLink(destination: ListView(title: "📚 Books", items: $bookList)) {
                            Image(systemName: "book.closed")
                                .foregroundColor(.orange)
                                .frame(width: 50, height: 50)
                                .background(Circle().fill(Color.white))
                                .shadow(radius: 3)
                        }
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(
                        RoundedRectangle(cornerRadius: 30)
                            .fill(Color(.systemGray6))
                            .shadow(radius: 4)
                    )
                }
            }
        }
    }
}

struct CardView: View {
    let title: String
    let color: Color
    
    var body: some View {
        Text(title)
            .frame(width: 150, height: 150)
            .background(
                LinearGradient(colors: [color.opacity(0.6), color.opacity(0.9)],
                               startPoint: .topLeading,
                               endPoint: .bottomTrailing)
            )
            .foregroundColor(.white)
            .cornerRadius(16)
            .shadow(radius: 5)
    }
}

struct ListView: View {
    let title: String
    @Binding var items: [String]
    @State private var newItem: String = ""
    
    var body: some View {
        VStack {
            HStack {
                TextField("Add new \(title)", text: $newItem)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                Button("Add") {
                    if !newItem.isEmpty {
                        items.append(newItem)
                        newItem = ""
                    }
                }
                .buttonStyle(.borderedProminent)
            }
            .padding()
            
            List {
                ForEach(items, id: \.self) { item in
                    Text(item)
                }
                .onDelete { indexSet in
                    items.remove(atOffsets: indexSet)
                }
            }
        }
        .navigationTitle(title)
        .toolbar {
            EditButton()
        }
    }
}

#Preview {
    ContentView()
}

